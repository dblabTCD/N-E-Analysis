# pileupTools
A tool to manipulate GATK pileup files (__Beta__ software)

##### Example usage

 ```bash
 # Quick Start
  ./pileupTools.py file.pileup -s my_sample

 # For help
 ./pileupTools.py -h
 ```
