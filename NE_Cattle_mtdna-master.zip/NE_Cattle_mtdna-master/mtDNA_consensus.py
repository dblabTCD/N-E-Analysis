#!/usr/bin/env python
""" Module docstring 
Created by Victoria E Mullin
Uploaded 16.05.19
This script takes a GATK pileup file, filters bases and converts into a consensus sequence.
To run:
python script.py name_pileup.txt bad_name.txt problem_name.txt consensus_name.txt
"""

import random
import sys

def main(input_file_name, bad_file_name, problembase_file_name, consensus_file_name):
    """ Main entry point. """
    bad_file = open(bad_file_name, 'w')
    problem_file = open(problembase_file_name, 'w')
    consensus_file = open(consensus_file_name, 'w')
    """print at this point the header into the consensus file"""
    consensus_file.write(">gi|12800|emb|V00654.1|"+input_file_name+"\n")
    
    line_no = 0
    for line in open(input_file_name):
        line_no += 1
        line = parse_line(line)

        if line is not None:
            if line['position'] < line_no:
                raise Exception("Position is going backwards")
            while line['position'] > line_no:
                consensus_file.write("N")
                line_no += 1

            if base_quality(line['quality']) < 3:
                bad_file.write(line["line"])
                consensus_file.write("N")
            else:
                max_coverage = maximum_coverage(line['bases'], line['quality'])
                consensus_file.write(max_coverage)
                if max_coverage not in ("A", "C", "T", "G"):
                    problem_file.write(line["line"])

def quality(character):
    return ord(character) - 33

def base_quality(string):
    """Check the base quality of the sequencing covering the base
    if there are less than 3 reads of a quality 30 then return True if more than 3 return false
    to do this: 1. split the string into individual characters, 2. test the individual characters, 3. count the outcome """
    outcomes = 0
    for character in string:
        if quality(character) > 19:
            outcomes += 1
    return outcomes

def cleaned_bases(bases, quality_string):
    if len(bases) != len(quality_string):
        raise Exception("bases and quality don't match")

    clean_bases = ""
    for i in range(0, len(bases)):
        if quality(quality_string[i]) > 19:
            clean_bases += bases[i]

    return clean_bases

def maximum_coverage(bases, quality_string):
    """ Call the base for the consensus sequence"""
### ask it to count number of A, C, T and G then choose the one with the greatest amount, if there is an even number print ambiguous code in the file and the 
line to the problem file
    counts = {"A": 0, "C": 0, "T": 0, "G": 0}
    for character in cleaned_bases(bases, quality_string):
        counts[character] += 1
    max_count = counts[max(counts, key=counts.get)]
    even_uneven = sorted([k for k in counts.keys() if counts[k] >= max_count])
    
    if even_uneven == ["A"]:
        return "A"
    elif even_uneven == ["C"]:
        return "C"
    elif even_uneven == ["T"]:
        return "T"
    elif even_uneven == ["G"]:
        return "G"
    elif even_uneven == ["A", "G"]:
        return "N"
    elif even_uneven == ["C", "T"]:
        return "N"
    elif even_uneven == ["C", "G"]:
        return "N"
    elif even_uneven == ["A", "T"]:
        return "N"
    elif even_uneven == ["G", "T"]:
        return "N"
    elif even_uneven == ["A", "C"]:
        return "N"
    return "N"
       
def parse_line(line):
    """ Parse a line and extract the fields we want to make decisions on. """
    if "Traversal result" in line:
        return None
    columns = line.split(' ')
    return {
        "line": line,
        "columns": columns,
        "position": int(columns[1]),
        "ref": columns[2],
        "bases": columns[3],
        "quality": columns[4],
    }

main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
