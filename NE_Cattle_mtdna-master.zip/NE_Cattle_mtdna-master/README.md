# NE_Cattle_mtdna

This directory contains the python script (mtDNA_consensus.py) used to create consensus mtDNA sequences for the paper "Ancient cattle genomics, origins and rapid turnover in the Fertile Crescent" Verdugo et al. 2019.

The input for this script is the output from GATK Pileup option.

The script outputs three files:

bad - positions where the coverage & or quality was not sufficient

problem - positions where there was a tie for the base (these are positions you need to check by eye)

consensus - the consensus

To run the script
```
python script pileup.txt bad_3X_name.txt problem_3X_name.txt consensus_3X_name.txt
```
Whilst the names of the output files may be changed, the order must be maintained.

If you want to use a higher coverage cut off or if you want a different base quality then the code must be changed.

